__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/370da92ec599c3a2.js",
  "static/chunks/turbopack-3904b0869407f2a7.js"
])
