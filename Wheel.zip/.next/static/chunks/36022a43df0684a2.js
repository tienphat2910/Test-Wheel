__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/370da92ec599c3a2.js",
  "static/chunks/turbopack-309549c1c67e457b.js"
])
