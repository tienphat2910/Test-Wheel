globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/370da92ec599c3a2.js",
      "static/chunks/turbopack-309549c1c67e457b.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/370da92ec599c3a2.js",
      "static/chunks/turbopack-3904b0869407f2a7.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b86ee4016e9cfcf5.js",
    "static/chunks/b7140e05bce67abe.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/turbopack-205e6309e7dedd0e.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];