var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__41c2c628._.js")
R.c("server/chunks/node_modules_next_c33a3258._.js")
R.m(18645)
R.m(21120)
module.exports=R.m(21120).exports
