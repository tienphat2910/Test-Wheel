"use client";
import React, { useState } from "react";
import Image from "next/image";
export type PrizeData = {
  option: string;
  price: number;
  description: string;
  image: string;
};

type PrizePopupProps = {
  open: boolean;
  data: PrizeData | null;
  onClose?: () => void;
  onClaim?: () => void;
};

function getBeefName(option: string) {
  // Lấy phần trước dấu "-" nếu có
  return option.split("-")[0].trim();
}

export default function PrizePopup({
  open,
  data,
  onClose,
  onClaim
}: PrizePopupProps) {
  const [copyStatus, setCopyStatus] = useState<string | null>(null);

  // Xác định Android
  const isAndroid =
    typeof window !== "undefined" &&
    /android/i.test(window.navigator.userAgent);

  // Kiểm tra clipboard API có thực sự khả dụng trên Android
  function canClipboardWork() {
    return (
      typeof window !== "undefined" &&
      !!navigator.clipboard &&
      !/FBAN|FBAV|Instagram|Zalo/i.test(window.navigator.userAgent)
    );
  }

  if (!open || !data) return null;

  const handleClaim = async () => {
    // Tracking GA4: Nhận mã
    if (typeof window !== "undefined") {
      // Use type assertion for window.gtag and window.dataLayer
      const win = window as Window & {
        gtag?: (...args: unknown[]) => void;
        dataLayer?: object[];
      };
      if (typeof win.gtag === "function") {
        win.gtag("event", "claim_code_click", {
          event_category: "prize",
          event_label: "Nhận mã"
        });
      } else if (Array.isArray(win.dataLayer)) {
        win.dataLayer.push({
          event: "claim_code_click",
          event_category: "prize",
          event_label: "Nhận mã"
        });
      }
    }

    // Tạo text gửi Messenger
    const beefName = getBeefName(data.option);
    const text = `Tôi đã nhận được món ${beefName} từ chương trình`;

    if (isAndroid) {
      window.open(
        `https://m.me/xyz.63631?text=${encodeURIComponent(text)}`,
        "_blank"
      );
    } else {
      window.open(
        `https://m.me/xyz.63631?text=${encodeURIComponent(text)}`,
        "_blank"
      );
    }

    if (onClaim) onClaim();
  };

  // Nút sao chép riêng cho Android
  const handleCopyOnly = async () => {
    // Đã bỏ generateCode, không còn chức năng copy code
    setCopyStatus(null);
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center">
      {/* Overlay phủ toàn bộ trang */}
      <div
        className="absolute inset-0 bg-black"
        style={{
          opacity: 0.8
        }}
      />
      <div className="relative z-10 flex items-center justify-center">
        <div
          className="flex flex-col items-center border border-[#FFF3E2] bg-[#FFF3E2] relative"
          style={{
            width: "398px",
            maxWidth: "95vw",
            borderRadius: 40,
            boxShadow: "0 8px 32px 0 rgba(0,0,0,0.18)",
            pointerEvents: "auto"
          }}
        >
          {/* Responsive width for desktop */}
          <style>
            {`
            @media (min-width: 768px) {
              .prize-popup-container {
                width: 560px !important;
              }
            }
          `}
          </style>
          <div className="prize-popup-container w-full flex flex-col items-center px-6 pt-8 pb-0">
            {/* Title */}
            <div className="text-center text-black text-[20px] md:text-[26px] font-bold mb-2 utm-centur">
              Chúc mừng Đồng Gu <br /> đã nhận được
            </div>
            {/* Option */}
            <div
              className="text-center font-voltra text-[20px] md:text-[25px] font-bold mb-1"
              style={{
                background:
                  "linear-gradient(180deg, #8F1713 0%, #CF3A05 114.44%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text" // cho các trình duyệt hỗ trợ chuẩn
              }}
            >
              1 Dĩa {data.option}
            </div>

            {/* Price */}
            <div
              className="text-center font-bold text-[14px] md:text-[20px] mb-3 font-voltra"
              style={{
                background:
                  "linear-gradient(180deg, #8F1713 0%, #CF3A05 114.44%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text" // hỗ trợ trình duyệt khác
              }}
            >
              Trị giá {data.price.toLocaleString()} VNĐ
            </div>
          </div>
          {/* Image full width container, giữ height */}
          <div className="w-full flex justify-center overflow-hidden">
            <Image
              src={data.image}
              alt={data.option}
              width={398}
              height={210}
              className="w-full h-[200px] md:h-[210px] object-cover"
              style={{ background: "#fff" }}
            />
          </div>

          <div className="prize-popup-container w-full flex flex-col items-center px-6 pb-0">
            {/* Description */}
            <div className="w-[350px] text-center text-black text-[16px] md:text-[20px] utm-centur mb-6 px-2 break-words">
              {data.description}
            </div>
          </div>
          {/* Button group */}
          <div className="w-full flex flex-row">
            <button
              onClick={handleClaim}
              className="flex-1 h-[56px] text-white flex items-center justify-center font-voltra"
              style={{
                fontSize: 18,
                borderRadius: "0 0 40px 40px",
                background:
                  "linear-gradient(180deg, #8F1713 0%, #CF3A05 114.44%)",
                letterSpacing: 1,
                cursor: "pointer"
              }}
            >
              NHẬN NGAY
            </button>
          </div>
          {/* Copy status & code */}
          {isAndroid && copyStatus && (
            <div className="w-full flex flex-col items-center mt-2 mb-2">
              <span className="text-black text-sm md:text-base">
                {copyStatus}
              </span>
            </div>
          )}
          {/* Icon đóng absolute dưới popup, căn giữa */}
          <button
            onClick={onClose}
            aria-label="Đóng"
            className="absolute left-1/2 -translate-x-1/2"
            style={{
              top: "100%",
              marginTop: 16,
              width: 36,
              height: 36,
              cursor: "pointer"
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="36"
              height="36"
              viewBox="0 0 36 36"
              fill="none"
            >
              <circle cx="18" cy="18" r="17.5" stroke="#FFF3E2" />
              <path
                d="M12 12L24 24"
                stroke="#FFF3E2"
                strokeWidth="2"
                strokeLinecap="round"
              />
              <path
                d="M24 12L12 24"
                stroke="#FFF3E2"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
